import 'package:flutter/material.dart';
Function EmailNavigationpage()
{
  print('Email Navigation function to be added.');
}