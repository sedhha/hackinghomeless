# hacking_homelessness

This is the mobile application for Hacking_Homelessness

## Getting Started

Flutter Project for the Mobile App. Note that firebase has been setup in android only and needs to be set up in IOS currently.